



import pika
import json
from atexit import register

mailService = None

class MailService:

    def __init__(self  , username = 'simon' , password = 'jinkela2020' , host = '111.229.242.38' , port = 5672 , queue = 'MailService'):
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.queue = queue

    def init(self):
        self.credentials = pika.PlainCredentials(self.username, self.password )
        self.connection = pika.BlockingConnection( pika.ConnectionParameters(host=self.host, port=self.port, virtual_host='/', credentials= self.credentials))
        self.channel = self.connection.channel()
        result = self.channel.queue_declare(queue=self.host)



    def send(self , productName , backgroundColor , backgroundColorImageUrl , title , mainPageUrl ,  buttonText , buttonUrl , imageUrl , mailAddress , subject ):


        combine = dict()
        combine["productName"] = productName
        combine["backgroundColor"] = backgroundColor
        combine["title"] = title
        combine["mainPageUrl"] = mainPageUrl
        combine["buttonText"] = buttonText
        combine["buttonUrl"] = buttonUrl
        combine["imageUrl"] = imageUrl
        combine["mailAddress"] = mailAddress
        combine["subject"] = subject
        combine["backgroundColorImageUrl"] = backgroundColorImageUrl

        message = json.dumps(combine)
        while( True ):
            try:
                self.channel.basic_publish(exchange = '',routing_key = self.queue ,body = message)
                break
            except:
                self.init()

    def close(self):
        self.connection.close()

@register
def _atexit():
    if mailService != None:
        mailService.close()

if __name__ == "__main__":
    mailService = MailService( host="cdn.stonybrook.club" )
    mailService.init()

    # so the function below
        # product name
        #   title text
        #   main page url location
        #   confirm button   showing text  and   url location
        #   image url

    # productName , backgroundColor , title , mainPageUrl ,  buttonText , buttonUrl , imageUrl
    # type = "reset", mail="simontangamerica@gmail.com" , name="鸡你太美" , url="www.google.com"


    mailService.send( productName = "BlueChat" ,
                      backgroundColor = "#4A707A" ,
                      title = "Hi Weixin, Authenticate your account to enjoy BlueChat" ,
                      mainPageUrl = "https://baidu.com" ,
                      buttonText = "Get started" ,
                      buttonUrl  = "https://baidu.com" ,
                      imageUrl = "https://simon.freeddns.org/img/bg.jpg" ,
                      backgroundColorImageUrl = "https://simon.freeddns.org/img/darkbluegreen.png",
                      mailAddress = "dz9@njit.edu" , #"simontangamerica@gmail.com" , 357504900@qq.com
                      subject = "鸡你太美"
                      )





