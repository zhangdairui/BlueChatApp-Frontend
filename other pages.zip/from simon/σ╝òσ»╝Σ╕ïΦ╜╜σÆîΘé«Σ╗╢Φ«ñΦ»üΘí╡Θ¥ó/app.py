
# docker build -t my_flask_module:latest .
# docker run -itd --link mysql:mysql -p 5000:5000 --name my_flask_module my_flask_module

# docker run -it  -p 5000:5000 --name my_flask_module my_flask_module
# docker container rm -f my_flask_module

#pip3 install cryptography

import pymysql
# import sqlite3
import atexit
import hashlib
import ssl
from flask import Flask , jsonify , redirect, url_for , request ,  session , render_template
from string import Template


app = Flask( __name__ )


flaskPort = 5000

# ______________________________________  the section blow for the web browser  ________________________________________________________________

@app.route('/')
def theMainPage(  ):
    return render_template(  myConfig.page_mainPage  )


# http://127.0.0.1:5000/reset/sucess

@app.route('/resetpwd/<token>' , methods=['GET'] )
def resetPasswordPage( token ):

    if (myTool.check_reset_pwd_token_if_exist(token) == True):
        return render_template(myConfig.page_resetPwd)
    else:
        return render_template(myConfig.page_checkFail)
        #return redirect(url_for('page_not_found'))

@app.route('/resetpwd/<token>' , methods=['POST'] )
def resetPwd( token ):
    #name = request.form['name']
    #location = request.form['location']
    #return 'hello {}. You are from {}. You have submitted the form successfully {} !'.format(name, location , token)
    if (myTool.check_reset_pwd_token_if_exist(token) == True):
        password = request.form['password']
        myTool.update_pwd_based_on_pwd_token( token , myTool.getHashValue( password ) )
        return render_template(myConfig.page_pwdPass)
    else:
        return render_template(myConfig.page_checkFail)


@app.route('/verify/<token>' , methods=['GET'] )
def authenticateAccountPage( token ):
    print( "what happened" )
    if( myTool.check_verify_token_if_exist( token ) == True ):
        myTool.update_authticate_to_null_based_on_verify_token( token )
        return render_template( myConfig.page_checkPass )
    else:
        #return redirect(url_for('page_not_found'))
        return render_template(myConfig.page_checkFail)

# now we need to see how form works
    #



@app.errorhandler(404)
def page_not_found(error):
   return render_template(myConfig.page_checkFail) , 404

# ______________________________________  the section above for the web browser  ________________________________________________________________

#http://localhost:5000/resetpwd/5644502e-23db-11eb-ad16-acde48001122

class MyDatabase:

    def __init__(self , dbAdress = 'cdn.vultr.stonybrook.me' , password = '*Vultr656'  ):
        pass
        #self.dbAdress = "./mysqlite.db"
        #self.db = self.connectDB()

        self.db = pymysql.connect(  dbAdress , 'root', password , 'cs656'  )

        atexit.register( self.db.close )

    def initDB(self):
        # queryUser = '''
        #     CREATE TABLE IF NOT EXISTS User(
        #       uuid char(255) primary key ,
        #       name char(255)   ,
        #       email char(255) not null unique ,
        #       photo char(255) ,
        #       cookie char(255),
        #       authenticate char(255) ,
        #       resetpassword char(255) ,
        #       password char( 287 )
        #     );
        # '''
        queryUser = '''
            CREATE TABLE IF NOT EXISTS User(
              uuid char(255) primary key ,
              name char(255)   ,
              email char(255) not null unique ,
              photo char(255) ,
              cookie char(255),
              authenticate char(255) ,
              resetpassword char(255) ,
              password TEXT
            );
        '''

        queryFriend = '''
            CREATE TABLE IF NOT EXISTS Friend(
                 requestid char(255) ,
                 acceptorid char(255) ,
                 buildtime timestamp 
            );
        '''

        cursor = self.getCursor()
        cursor.execute( queryUser )
        cursor.execute( queryFriend )
        self.db.commit()

    def clearDB(self):
        queryUser = '''
            DROP TABLE IF EXISTS User ;
        '''
        queryFriend = '''
            DROP TABLE IF EXISTS Friend ;
        '''

        cursor = self.getCursor()
        cursor.execute(queryUser)
        cursor.execute(queryFriend)
        self.db.commit()

    # def connectDB( self , ):
    #     sql = sqlite3.connect(self.dbAdress)
    #     #sql.row_factory = sqlite3.Row
    #     return sql

    def getCursor(self):
        return self.db.cursor()

    def commit(self):
        self.db.commit()

class MyConfig:

    def __init__(self):
        pass

        self.page_mainPage = "0_mainPage.html"
        self.page_pwdPass = "1_passwordResetSucess.html"
        self.page_resetPwd = "2_resetPassword.html"
        self.page_checkFail = "3_verificationFailed.html"
        self.page_checkPass = "4_verificationSucess.html"



class MyTool:
    def __init__(self):
        pass

    # here we need create a set of help function

    # UPDATE User SET authenticate = NULL WHERE authenticate = %s ;
    # SELECT COUNT(*) mynum FROM User WHERE authenticate = %s ;
    # UPDATE User SET resetpassword = NULL WHERE resetpassword = %s ;
    # UPDATE User SET password = %s WHERE resetpassword =  %s ;

    def check_verify_token_if_exist(self , verify_token ):
        pass
        if( verify_token == '' ):
            return False
        cursor = myDB.getCursor()
        cursor.execute("SELECT COUNT(*) mynum FROM User WHERE authenticate = %s ;" , (  verify_token , ) )
        result = (cursor.fetchone())[0]
        myDB.commit()
        if( result == 1 ):
            return True
        else:
            return False

    def check_reset_pwd_token_if_exist(self , reset_pwd_token ):
        pass
        if ( reset_pwd_token == ''):
            return False
        cursor = myDB.getCursor()
        cursor.execute("SELECT COUNT(*) mynum FROM User WHERE resetpassword = %s ;", (reset_pwd_token , ))
        result = (cursor.fetchone())[0]
        myDB.commit()
        if (result == 1):
            return True
        else:
            return False

    def update_pwd_based_on_pwd_token(self , reset_pwd_token , password ):
        pass
        cursor = myDB.getCursor()
        cursor.execute("UPDATE User SET resetpassword = NULL , password = %s WHERE resetpassword = %s ;", (password, reset_pwd_token ))
        myDB.commit()

        # UPDATE User SET resetpassword = NULL , password = %s WHERE resetpassword = %s ;

    def update_authticate_to_null_based_on_verify_token(self , verify_token  ):
        pass
        # UPDATE User SET authenticate = NULL WHERE authenticate = %s ;
        # sha 256
        cursor = myDB.getCursor()
        cursor.execute("UPDATE User SET authenticate = NULL WHERE authenticate = %s ;",  ( verify_token , ))
        myDB.commit()

    def getHashValue(self, myStr):
        result = hashlib.sha256(myStr.encode())
        return str(result.hexdigest())


if __name__ == '__main__':

    myConfig = MyConfig()
    myTool = MyTool()
    myDB = MyDatabase(dbAdress="localhost" , password="myVultr656" )
    #myDB = MyDatabase(  )
    #myDB = MyDatabase(  dbAdress= "mysql" , password="myVultr656"  )
    # myDB.clearDB()
    myDB.initDB()

    #myTool.check_reset_pwd_token_if_exist(  )

    #print( myTool.check_verify_token_if_exist("5644502e-23db-11eb-ad16-acde48001122") )

    #myTool.update_authticate_to_null_based_on_verify_token( "5644502e-23db-11eb-ad16-acde48001122" )
    app.run(debug=False, port=flaskPort, host='localhost')
    #app.run( debug=False , port= flaskPort , host='localhost' )
    pass


#cursor = myDB.getCursor()
#cursor.execute( "CREATE TABLE IF NOT EXISTS Person( id integer primary key , name char(255)  )" )
#cursor.execute( "INSERT INTO Person ( id, name ) VALUES ( ? , ? )" , ( 3, 'gzg' ) )
#cursor.execute("SELECT * FROM Person");
#result =  cursor.fetchall()
#for i in result:
#   print( i )
#myDB.commit()


#mySqlManager = MysqlManager( myDatabase )
#mySqlManager.initDatabase()
#print( mySqlManager.checkUserTableExist() )
#mySqlManager.createUserTable()

# @app.route('/home', methods=['POST','GET'] , defaults={'name': 'Default'} )
# @app.route('/home/<name>' , methods=['POST','GET'] )
# def home( name ):
#     return '<h1>You {}, are on the home page</h1>'.format(name)
#
# @app.route('/json')
# def json():
#     return jsonify({ 'key' : 'value' , 'key2':[1,2,3] })



# 接受到网页链接
    # 把 链接后面的数据抓过来 ， 如果 失败 就返回失败页面

    #  / type /  uuid
    #    resetpassword  /   xxxx
    #    authentication /  xxxx

    # 分支


# pass
# if request.method == 'GET':
#     if( myTool.check_reset_pwd_token_if_exist( token ) == True ):
#         return render_template( myConfig.page_resetPwd )
#     else:
#         return render_template( myConfig.page_checkFail )
#
# elif request.method == 'POST':
#         pass
#     if (myTool.check_reset_pwd_token_if_exist(token) == True):


# if request.method == 'GET':
#
#     if( token == 'sucess' ):
#         return render_template(htmlPath['resetPwd'])
#     else:
#         return render_template( htmlPath['checkFail'] )
# elif request.method == 'POST':
#     pass
#
# #return render_template( htmlPath['resetPwd'] )
#
# return '<h1>666 {}</h1>'.format( token )
# return  redirect(url_for('thehome', name=name , location=location ))
# return redirect(url_for('theMainPage'  ) )



# if (token == 'sucess'):
#     return render_template(htmlPath['checkPass'])
# else:
#     return render_template(htmlPath['checkFail'])
#
# return '<h1>666 {}</h1>'.format( token )


















