
-- 0 表示还没有验证邮箱 authenticate
-- 1 表示验证成功 authenticate

CREATE TABLE User(
    id CHAR(63) PRIMARY KEY ,
    username CHAR(255) NOT NULL DEFAULT '',
    email CHAR(255) NOT NULL UNIQUE ,
    cookie CHAR(255) NOT NULL ,
    authenticate INTEGER ,
    image TEXT,
    resetpasspordurl CHAR(63)
);

CREATE TABLE Friend(
    idReq CHAR(63) ,
    idRec CHAR(63)
);

CREATE TABLE Invite(
    idReq CHAR(63) ,
    idRec CHAR(63) ,
    time timestamp
);











