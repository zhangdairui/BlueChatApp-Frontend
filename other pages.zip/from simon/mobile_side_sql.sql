

-- 没有验证 又跑去注册呢
    -- 可以的
    -- 没有验证可以再次注册


-- 这table里就只会有他本人的信息


CREATE TABLE SelfInfo(
    id CHAR(63) PRIMART KEY,
    username CHAR(255) NOT NULL DEFAULT '',
    email CHAR(255) NOT NULL UNIQUE ,
    cookie CHAR(255) NOT NULL ,
    sequence DOUBLE NOT NOT DOUBLE 0 ,
    image TEXT ,
);

-- 这里包含向他发出邀请的人 和 他的好友

CREATE TABLE UserInfo(
    id CHAR(63) PRIMART KEY,
    username CHAR(255) NOT NULL DEFAULT '',
    email CHAR(255) NOT NULL UNIQUE,
);


CREATE TABLE FriendList(
    id CHAR(63) PRIMART KEY,
    sequence DOUBLE NOT NOT
);

-- 邀请求加的好友列表
CREATE TABLE InviteList(
    id CHAR(63) PRIMART KEY,
    time timestamp
);

-- 这里是所有的消息
-- 这里的内容是有限的 要小于60kb

CREATE TABLE Message(
    sender CHAR(63) ,
    receiver CHAR(63) ,
    content TEXT,
    time timestamp
);





























